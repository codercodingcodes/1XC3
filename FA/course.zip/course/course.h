/**
 * @file course.h
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief the course structure contains a string name with a character limit of 100, a string ID with a character limit of 10, a student structure and an integer of the amount of students enrolled.
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


